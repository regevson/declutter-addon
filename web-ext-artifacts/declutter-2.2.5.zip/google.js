var mainbar = document.getElementById("main");
//mainbar.style.background = 'black';

var results = document.getElementsByClassName("g");
for(var i = 0; i < results.length; i++) {
	var result = results[i];
	result.style.background = "rgb(234, 234, 234)";
	result.style.padding = "5px";
	result.style.borderRadius = "10px";
	result.style.marginBottom = "25px";
}


var margin = document.getElementsByClassName("hlcw0c");
margin = margin[0];
margin.style.marginBottom = "0px";

margin = document.getElementsByClassName("ULSxyf");
margin = margin[0];
margin.style.marginBottom = "0px";

margins = document.getElementsByClassName("jNVrwc");
for(var i = 0; i < margins.length; i++) {
	var margin = margins[i];
	margin.style.marginBottom = "0px";
	margin.style.background = "none";
}

var extrabgs = document.getElementsByClassName("xpdopen");
for(var i = 0; i < extrabgs.length; i++) {
	var bg = extrabgs[i];
	bg.style.background = "rgb(234, 234, 234)";
}


/*
var colors = document.getElementsByClassName("yDYNvb");
for(var i = 0; i < colors.length; i++) {
	var color = colors[i];
	color.style.color = "black";
}
*/
